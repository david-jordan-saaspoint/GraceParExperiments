
      $(function () {  
        $('#alert').click(function () {  
         // alert('Hello, world!'); 
         alert(this.getAttribute('message')); 
          return false;  
        })  
      });  
  