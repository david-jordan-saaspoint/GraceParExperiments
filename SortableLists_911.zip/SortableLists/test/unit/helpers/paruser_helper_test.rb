require 'test_helper'

class ParuserHelperTest < ActionView::TestCase
end
