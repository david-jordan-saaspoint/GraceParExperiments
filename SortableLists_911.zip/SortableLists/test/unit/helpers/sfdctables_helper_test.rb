require 'test_helper'

class SfdctablesHelperTest < ActionView::TestCase
end
