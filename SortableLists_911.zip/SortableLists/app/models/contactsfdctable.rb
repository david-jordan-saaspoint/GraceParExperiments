class Contactsfdctable < ActiveRecord::Base
end
