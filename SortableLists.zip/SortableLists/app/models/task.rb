class Task < ActiveRecord::Base
end
