class Pardb < ActiveRecord::Base
end
