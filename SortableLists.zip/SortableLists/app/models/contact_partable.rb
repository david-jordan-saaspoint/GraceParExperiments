class ContactPartable < ActiveRecord::Base
end
