class Sfdctable < ActiveRecord::Base
end
