class Partable < ActiveRecord::Base
end
