class Selectedcontactfield < ActiveRecord::Base
end
