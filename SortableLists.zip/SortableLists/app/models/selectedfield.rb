class Selectedfield < ActiveRecord::Base
end
