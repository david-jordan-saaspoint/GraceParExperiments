# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SortableLists::Application.config.secret_token = 'b130c86630fd869bfeb0a83332b7722a434c6d22a8f87986c51ded40f8cb04f4bcf63b62c5ac5a1cd2a8e54e3afc2a226861d5e560f7a56d3744ca6d47dc8444'
