require 'test_helper'

class SfFieldsHelperTest < ActionView::TestCase
end
