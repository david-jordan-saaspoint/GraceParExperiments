require 'test_helper'

class SfdcsHelperTest < ActionView::TestCase
end
