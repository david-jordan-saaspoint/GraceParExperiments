#!/bin/sh
curl https://na12-api.salesforce.com/services/data/v20.0 -H 'Authorization: OAuth 00DU0000000ITUe!ASAAQDaRfoPHo8E4F_UuQsZAo6Z4LcIyS_S62qCNqfkuzmR2uKE5tGQ5Yb6FFDpFzhThO_b.HhMF3cGFEacyCe3fR5.vQafQ'

