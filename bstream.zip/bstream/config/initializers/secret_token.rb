# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Bstream::Application.config.secret_token = 'b4c42c16ba9028760ce8d6a4160c714b08d7446f441e6da92ac4ab7574e698a8375d826c7cffad2146f52c476234729fa64a29b2e46340093306ea438f21350d'
