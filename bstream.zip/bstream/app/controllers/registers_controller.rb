require 'rubygems'
require 'databasedotcom'
require 'httparty'
# require 'open-uri'
#  require 'uri'
class RegistersController < ApplicationController
  
  def new
    @title = [ "Please select..." , "Mr", "Ms", "Miss", "Mrs", "Dr"]
    @register = Register.new
    
  end

  def create
     @title = [ "Please select..." , "Mr", "Ms", "Miss", "Mrs", "Dr"]
     @register = Register.new(params['register'])
    if @register.valid?
      # TODO send message here
      save_registration
      
    else
      render :action => 'new'
    end
  end
  def save_registration
   p "save"
    @mapped_hash = Hash.new
    @mapped_hash = params['register']
    @mapped_hash[:title] = "Mr" if @mapped_hash[:title] == "Please select..."
    p "mapped", @mapped_hash
    
    # based on the CRN and SPID provided trace the account details
    get_account_number(@mapped_hash)
    get_account_number_user(@mapped_hash)
    compare_accountIds(@result_hash, @user_hash) if ((@user_hash.blank? == false) and (@result_hash.blank? == false))
    # based on the account record upsert contact details
  #  upsert_contact_details(@mapped_hash)
    # create a new customer portal
    create_new_cp_record
    
    # email a new username and password
    
    UserMailer.deliver_registration_confirmation(@mapped_hash)
    p "sent mail"
  end
  
  def get_account_number(mapped_hash)
    begin
      accounts = client.materialize("Account")
      @result_hash= client.query("SELECT Name,Id from Account where (Id = '#{mapped_hash["crn"] }') ")
      mapped_hash["accId"] = @result_hash.Id
     
 #   sites = client.materialize("Site__c")
 #   @result_hash = client.query("SELECT accountId from Site__c where crn__c = '#{mapped_hash["crn"]}' ")
 #    mapped_hash["accId"] = @result_hash.accountId
    rescue Exception => e
      p "RESCUE1"
      # handle exception here if CRN not found in site__c
      begin
        @result_hash= client.query("SELECT Name,Id from Account where (AccountNumber = '#{mapped_hash["spid"] }')")
        mapped_hash["accId"] = @result_hash.Id
     #  @result_hash = client.query("SELECT accountId from Site__c where spid__c = '#{mapped_hash["spid"]}' ")
     #  mapped_hash["accId"] = @result_hash.accountId
      rescue Exception => e
      p e
      p "rescue 2"
      # handle exception here if CRN not found in site__c
      end
    end
    
  end
  def get_account_number_user(mapped_hash)
     begin
       p "checking user"
        users = client.materialize("User")
     p  @user_hash= client.query("SELECT Name, AccountId from User where username = '#{mapped_hash["email"] }' ")
     
     if @user_hash.empty?
       upsert_contact_details(mapped_hash, client)
     end
     # p accountId = result_hash.Id
 #   users = client.materialize("User")
 #   @result_hash = client.query("SELECT accountId from Site__c where crn__c = '#{mapped_hash["crn"]}' ")
  #  p accountId = result_hash.accountId
    rescue Exception => e
      p "rescue 3"
      p e
      # handle exception here if id not found in user by creating new user
      upsert_contact_details(mapped_hash, client)
      
    end
  end
  def create_new_user(mapped_hash)
    
  end
  def compare_accountIds(result_hash, user_hash)
  #  p "result_hash.Id", result_hash
  #  p "user_hash.AccountId", user_hash
    # %%%%%%%%%%%%%%%%%%%%  do we need to update any fields based on the data collected for the user??&&&&&&&
    site_accountId = Array.new
    user_accountId = Array.new
    result_hash.each {|rec| site_accountId.push(rec.Id)}
    user_hash.each {|rec| user_accountId.push(rec.Id)}
    registered = site_accountId & user_accountId
    if registered.empty?
      # handle user registered to different account
      p " user found but registered to different account"
    else
      # handle user exists
      p "user found and registered to correct account"
    end
  end
  def upsert_contact_details(mapped_hash, client)
    p mapped_hash
    p "inserting contact"
    contacts = client.materialize("Contact")
    Contact.create("Contact", {"FirstName" => '#{mapped_hash["fname"]',"LastName" => '#{mapped_hash["lname"]', "Email" => '#{mapped_hash["email"]', "AccountId" => '#{mapped_hash["accId"]' } )
    "done"
  end
  def create_new_cp_record
    
  end
  
end
